package com.example.demo;

public class MyRequestBody {
    private int m;
    private double a;
    private double b;
    private String f;
    private double eps;

    public int getM() {
        return m;
    }

    public void setM(int m) {
        this.m = m;
    }

    public double getA() {
        return a;
    }

    public void setA(double a) {
        this.a = a;
    }

    public double getB() {
        return b;
    }

    public void setB(double b) {
        this.b = b;
    }

    public String getF() {
        return f;
    }

    public void setF(String f) {
        this.f = f;
    }

    public double getEps() {
        return eps;
    }

    public void setEps(double eps) {
        this.eps = eps;
    }
}
