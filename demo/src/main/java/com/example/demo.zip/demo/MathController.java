package com.example.demo;

import java.math.BigDecimal;
import java.util.ArrayList;


import org.springframework.web.bind.annotation.*;

@RestController
public class MathController {
    @PostMapping("/getFs")
    public Object getFuncs(@RequestBody MyIterRequestBody body){
        ArrayList<String> graphFs = new ArrayList<>();
        ItarationMethod iMethod = new ItarationMethod(body.getFs(),body.getA() ,body.getB() ,body.getEps() );
        ArrayList<Double> ans = iMethod.findAnswer();
        graphFs.addAll(body.getFs());
        for (int j = 0; j < graphFs.size(); j++) {
            graphFs.set(j,"("+graphFs.get(j).concat(")-("+String.valueOf((char)(j+97))+")"));
            for (int i = 98; i < graphFs.size()+97; i++) {
                graphFs.set(j, graphFs.get(j).replaceAll(String.valueOf((char)(i)),"("+String.valueOf(ans.get(i-97) )+")"));
                graphFs.set(j, graphFs.get(j).replaceAll("a", "x"));
            }
        }
        return graphFs;
    }
    @PostMapping("/goIter")
    public Object solveIter(@RequestBody MyIterRequestBody body){
        try{
            ItarationMethod iMethod = new ItarationMethod(body.getFs(),body.getA() ,body.getB() ,body.getEps() );
            ArrayList<Double> res = iMethod.findAnswer();
            boolean isNaN = false;
            for (int i = 0; i < res.size(); i++) {
                if(res.get(i).isNaN() || res.get(i).isInfinite()) return "e404";
            }
            return res;
        }catch (RuntimeException e){
            return "e404";
        }
    }
    @PostMapping("/go")
    public Object solve1(@RequestBody MyRequestBody body){
        if(body.getM()==1){
            try{
                BisectionMethod dMethod = new BisectionMethod(body.getF(), body.getA(), body.getB(), body.getEps());
                double ans = dMethod.findRandomAnswer();
                if(Double.isNaN(ans)){
                    return "Ф-я на интервале должна быть ионотонной и не иметь точек экстремума. Иначе мы ничего не гарантируем" ;
                }
                return ans;
            }catch (ArithmeticException e){
                return "e404";
            }catch (NullPointerException e){
                return "e405";
            }
        }
        else {
            try{
                TangentMethod tMethod = new TangentMethod(body.getF(), body.getA(), body.getB(), body.getEps());
                double ans = tMethod.findRandomAnswer();
                if(Double.isNaN(ans)){
                    return "e406" ;
                }
                if(ans< body.getA() || ans>body.getB()){
                  return "e406";
                }
                return ans;
            }catch (ArithmeticException e){
                return "e404";
            }
        }
    }
}