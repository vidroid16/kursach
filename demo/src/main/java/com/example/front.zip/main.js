import Vue from 'vue'
import App from './App.vue'
import VueResource from "vue-resource"
import VueRouter from "vue-router";
import axios from "axios"
import Vuex from "vuex"
import vuetify from './plugins/vuetify.js';
import 'vuetify/dist/vuetify'
Vue.use(VueResource);
Vue.use(axios);
Vue.use(Vuex);
Vue.use(VueRouter);
Vue.use(vuetify);

const instance = axios.create({baseURL: 'http://localhost:8080/'})

const store = new Vuex.Store({
  state: {
    url:'http://localhost:8080/',
    result:0,
    data:[],
    a: -2.5,
    b: 2.5,
  },
  mutations: {
    addData(state, val){
      state.data.push(val);
    },
    clearData(state){
      state.data = [];
    },
    seta(state, val){
      state.a = val;
    },
    setb(state, val){
      state.b = val;
    },
    setRes(state, val){
      state.result = val;
    }
  }
})

Vue.config.productionTip = false

var router = new VueRouter({
  routes:[
    {path: '/', beforeEnter: () => {
      this.router.push('/home');
    }},
    {path:'/home', component: App}
  ]
})

new Vue({
  store,
  instance,
  router,
  vuetify,
  render: h => h(App)
}).$mount('#app')
