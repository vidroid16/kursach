<template>
  <v-app>
    <v-app-bar app color=rgba(222,222,13,0.6)>
      <v-toolbar-title> Лаборатаорная работа №3</v-toolbar-title>
    </v-app-bar>
    <v-content>
      <div class="container-m">
        <v-card class="mycard" id="options-box">
          <v-card-title>Настройки</v-card-title>
          <Options/>
          <div class="options"></div>
        </v-card>
        <v-card class="mycard" id="graph-box">
          <v-card-title>График</v-card-title>
          <Graph/>
          <div class="options"></div>
        </v-card>
      </div>
      <v-card class="mycard" id="result-box">
        <v-card-title>Результат</v-card-title>
        <div class="options">x = {{this.$store.state.result}}</div>
      </v-card>
    </v-content>
    <TestComponent/>
  </v-app>
</template>

<script>
import Options from './components/Options';
import Graph from './components/Graph';

export default {
  name: 'App',

  components: {
    Options,
    Graph
  },

  data: () => ({
    res: this.$store.state.result
  }),
};
</script>

<style >
  .mycard{
    width: 50%;
  }
  .container-m{
    width: 100%;
    display: flex;
    flex-direction: row;
  }
  #options-box{
    height: 500px;
    overflow-y: auto;
    overflow-x: hidden;
  }
  #result-box{
    width: 100%;
  }
</style>